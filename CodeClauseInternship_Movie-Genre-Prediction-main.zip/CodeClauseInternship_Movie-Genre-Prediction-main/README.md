Project title: Movie Genre Prediction
Aim:  Predict the genre of a movie based on its plot summary and other features.
Description: Use natural language processing (NLP) techniques for text classification on a movie dataset.
Learnings: Text classification with NLP

Input dataset: train.csv, test.csv
Output dataset: predicted_genres.csv
